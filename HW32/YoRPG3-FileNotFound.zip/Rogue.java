/*=============================================
  class Rogue -- protagonist of Ye Olde RPG  
  =============================================*/
 
public class Rogue extends Character {

    // ~~~~~~~~~~~ INSTANCE VARIABLES ~~~~~~~~~~~
    // inherited from superclass
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


    /*=============================================
      default constructor
      pre:  instance vars are declared
      post: initializes instance vars.
      =============================================*/
    public Rogue() {
	super();
	_hitPts = 50;
	_strength = 100;
	_defense = 30;
	_attack = 0.9;
    }


    /*=============================================
      overloaded constructor
      pre:  instance vars are declared
      post: initializes instance vars. _name is set to input String.
      =============================================*/
    public Rogue( String name ) {
        super(name);
    }

    /*=============================================
      overridden toString()
      pre:  
      post: returns name of class
      =============================================*/
    public String toString () {
	return "Rogue";
    }
    

}//end class Rogue
