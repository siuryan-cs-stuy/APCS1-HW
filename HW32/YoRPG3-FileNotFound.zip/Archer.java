/*=============================================
  class Archer -- protagonist of Ye Olde RPG  
  =============================================*/
 
public class Archer extends Character {

    // ~~~~~~~~~~~ INSTANCE VARIABLES ~~~~~~~~~~~
    // inherited from superclass
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


    /*=============================================
      default constructor
      pre:  instance vars are declared
      post: initializes instance vars.
      =============================================*/
    public Archer() {
	super();
	_hitPts = 75;
	_strength = 60;
	_defense = 25;
	_attack = .7;
    }


    /*=============================================
      overloaded constructor
      pre:  instance vars are declared
      post: initializes instance vars. _name is set to input String.
      =============================================*/
    public Archer( String name ) {
        super(name);
    }

    /*=============================================
      overridden toString()
      pre:  
      post: returns name of class
      =============================================*/
    public String toString () {
	return "Archer";
    }


}//end class Archer
