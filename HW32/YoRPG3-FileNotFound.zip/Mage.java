/*=============================================
  class Mage -- protagonist of Ye Olde RPG  
  =============================================*/
 
public class Mage extends Character {

    // ~~~~~~~~~~~ INSTANCE VARIABLES ~~~~~~~~~~~
    // inherited from superclass
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


    /*=============================================
      default constructor
      pre:  instance vars are declared
      post: initializes instance vars.
      =============================================*/
    public Mage() {
	super();
	_hitPts = 100;
	_strength = 70;
	_defense = 20;
	_attack = .8;
    }


    /*=============================================
      overloaded constructor
      pre:  instance vars are declared
      post: initializes instance vars. _name is set to input String.
      =============================================*/
    public Mage( String name ) {
        super(name);
    }

    /*=============================================
      overridden toString()
      pre:  
      post: returns name of class
      =============================================*/
    public String toString () {
	return "Mage";
    }


}//end class Mage
