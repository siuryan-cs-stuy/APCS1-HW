/*=============================================
  class Priest -- protagonist of Ye Olde RPG  
  =============================================*/
 
public class Priest extends Character {

    // ~~~~~~~~~~~ INSTANCE VARIABLES ~~~~~~~~~~~
    // inherited from superclass
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


    /*=============================================
      default constructor
      pre:  instance vars are declared
      post: initializes instance vars.
      =============================================*/
    public Priest() {
	super();
	_hitPts = 150;
	_strength = 50;
	_defense = 35;
	_attack = .5;
    }


    /*=============================================
      overloaded constructor
      pre:  instance vars are declared
      post: initializes instance vars. _name is set to input String.
      =============================================*/
    public Priest( String name ) {
	super(name);
    }

    /*=============================================
      overridden toString()
      pre:  
      post: returns name of class
      =============================================*/
    public String toString () {
	return "Priest";
    }


}//end class Priest
